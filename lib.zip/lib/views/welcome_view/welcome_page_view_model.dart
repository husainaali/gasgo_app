import '../../services/base_model.dart';
class WelcomePageViewModel extends BaseModel {
  initialize() {}
}