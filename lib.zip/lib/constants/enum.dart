part of 'constants_helper.dart';

enum OperationModes { test, production }