import 'package:auto_size_text/auto_size_text.dart';
import 'package:flutter/material.dart';
import 'package:gap/gap.dart';
import 'package:stacked/stacked.dart';

import '../../constants/constants_helper.dart';
import '../../widgets/custom_widget_helper.dart';
import 'design_page_view_model.dart';

class DesignListPageView extends StatelessWidget {
  const DesignListPageView({super.key});

  @override
  Widget build(BuildContext context) {
    return ViewModelBuilder<DesignPageViewModel>.reactive(
        viewModelBuilder: () => DesignPageViewModel(),
        onViewModelReady: (model) => model.initialize(),
        builder: (context, model, child) => Scaffold(
            backgroundColor: AppColor.appColorWhite,
            body: Scaffold(
                appBar: customAppBarBig(context, model, ""),
                backgroundColor: AppColor.appColorMain,
                body: Stack(
                  children: [
                    SizedBox(
                      width: Size.infinite.width,
                      height: Size.infinite.height,
                      child: GestureDetector(
                        onTap: () {},
                        child: Image.asset(
                          'assets/homebackground.png',
                          fit: BoxFit.cover,
                        ),
                      ),
                    ),
                    SafeArea(
                      child: Container(),
                       
                )
                  ]
                )
                )
                ));
                
  }
}
