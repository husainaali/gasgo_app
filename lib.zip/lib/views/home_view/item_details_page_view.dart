import 'dart:developer';

import 'package:gasgo_app/widgets/custom_widget_helper.dart';
import 'package:flutter/material.dart';
import 'package:gap/gap.dart';
import 'package:stacked/stacked.dart';
import 'package:auto_size_text/auto_size_text.dart';

import '../../constants/constants_helper.dart';
import 'home_page_view_model.dart';

class ItemDetailsPageView extends StatelessWidget {
  const ItemDetailsPageView({super.key});

  @override
  Widget build(BuildContext context) {
    return ViewModelBuilder<HomePageViewModel>.reactive(
        viewModelBuilder: () => HomePageViewModel(),
        onViewModelReady: (model) => model.initializeDetailsPage(),
        builder: (context, model, child) => Scaffold(
            appBar: customAppBarSmall(context),
            backgroundColor: AppColor.appColorMain,
            body: Stack(
              children: [
                SizedBox(
                  width: Size.infinite.width,
                  height: Size.infinite.height,
                  child: GestureDetector(
                    onTap: () {},
                    child: Image.asset(
                      'assets/homebackground.png',
                      fit: BoxFit.cover,
                    ),
                  ),
                ),
                SafeArea(
                    child: ListView(
                  children: [
                    const Gap(25),
                    SizedBox(
                        height: customHeight(context, percentage: 0.73),
                        width: customWidth(context),
                        child: Row(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            SizedBox(
                              height: customHeight(context, percentage: 0.675),
                              child: Stack(
                                children: [
                                  Padding(
                                    padding: const EdgeInsets.only(bottom: 5.0),
                                    child: Container(
                                      decoration: BoxDecoration(
                                        borderRadius: BorderRadius.circular(30),
                                      ),
                                      child: Image.asset("assets/gasgo.png"),
                                    ),
                                  ),
                                  Align(
                                    alignment: Alignment.bottomCenter,
                                    child: Column(
                                      mainAxisAlignment: MainAxisAlignment.end,
                                      children: [
                                        Container(
                                          decoration: BoxDecoration(
                                            color: const Color.fromARGB(
                                                255, 100, 75, 71),
                                            borderRadius: BorderRadius.only(
                                              bottomLeft: Radius.circular(20),
                                              topRight: Radius.circular(20),
                                              bottomRight: Radius.circular(20),
                                            ),
                                          ),
                                          child: Row(
                                            crossAxisAlignment:
                                                CrossAxisAlignment.start,
                                            mainAxisAlignment:
                                                MainAxisAlignment.center,
                                            children: [
                                              Gap(20),
                                              Text(
                                                "Price",
                                                style: TextStyle(
                                                  color: Colors.grey,
                                                  fontSize: 16,
                                                ),
                                              ),
                                              Text(
                                                "8.9",
                                                style: TextStyle(
                                                  color: Colors.white,
                                                  fontSize: 60,
                                                  fontWeight: FontWeight.bold,
                                                ),
                                              ),
                                              Text(
                                                "BHD",
                                                style: TextStyle(
                                                  color: Colors.grey,
                                                  fontSize: 16,
                                                ),
                                              ),
                                              Gap(20),
                                            ],
                                          ),
                                        ),
                                        Transform.scale(
                                          scale: 0.6,
                                          child: Row(
                                            mainAxisAlignment:
                                                MainAxisAlignment.spaceAround,
                                            children: [
                                              IconButton(
                                                style: ButtonStyle(
                                                  backgroundColor:
                                                      WidgetStateProperty.all(
                                                          AppColor
                                                              .appColorBlack),
                                                ),
                                                onPressed: () {
                                                  model.itemQtyCounter("-");
                                                },
                                                icon: Icon(
                                                  Icons.remove,
                                                  color: AppColor.appColorWhite,
                                                ),
                                              ),
                                              SizedBox(
                                                  width: customWidth(context,
                                                      percentage: 0.18),
                                                  height: customHeight(context,
                                                      percentage: 0.05),
                                                  child: Center(
                                                      child: LimitedBox(
                                                          child: AutoSizeText(
                                                    model.itemQty.toString(),
                                                    maxFontSize: 36,
                                                    minFontSize: 24,
                                                  )))),
                                              IconButton(
                                                style: ButtonStyle(
                                                  backgroundColor:
                                                      WidgetStateProperty.all(
                                                          AppColor
                                                              .appColorBlack),
                                                ),
                                                onPressed: () {
                                                  model.itemQtyCounter("+");
                                                },
                                                icon: Icon(
                                                  Icons.add,
                                                  color: AppColor.appColorWhite,
                                                ),
                                              ),
                                            ],
                                          ),
                                        ),

                                         ElevatedButton(
                          child: Text(
                            "Add Cart",
                            style: TextStyle(color: Colors.white, fontSize: 18),
                          ),
                          style: ButtonStyle(
                              backgroundColor:
                                  WidgetStateProperty.all(Colors.black)),
                          onPressed: () {
                       

                          },
                        ),
                                      ],
                                    ),
                                  ),
                                ],
                              ),
                            ),
                           
                        ],
                      ),
                    ),
                  ],
                ))
              ],
            )));
  }
}
