// TODO Implement this library.


import '../../services/base_model.dart';

class SettingPageViewModel extends BaseModel {
  initialize() {}

}