class AppString {

// APIs path
  static const getKnowledgeBaseCategory = "/category/list";

// shared preferences key
  static const isUserLogInKey = "is_user_login_key";
  static const userData = "user_data";
  
}