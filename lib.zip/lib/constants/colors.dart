part of 'constants_helper.dart';

class AppColor {
  static const Color appColorMainRed = Color(0xFFE6452D);
  static const Color appColorMain = Color(0xFFDFDDCF);
  static const Color appColorGreylight = Color(0xFFEEEEEE);
  static const Color appColorGreylight2 = Color(0xFFD9D9D9);
  static const Color appColorGreyNormal = Color(0xFFA3A3A3);
  static const Color appColorGreyDark = Color(0xFF616161);
  static const Color appColorWhite = Color(0xFFFFFFFF);
  static const Color appColorBlack = Color(0xFF000000);
}