import 'package:flutter/material.dart';

part 'config.dart';
part 'enum.dart';
part 'colors.dart';